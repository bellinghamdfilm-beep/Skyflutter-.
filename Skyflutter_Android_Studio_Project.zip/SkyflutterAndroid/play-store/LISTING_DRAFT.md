# Google Play listing draft

**App name:** Skyflutter: A Tiny Sky Adventure

**Short description (80 characters max):** A dreamy one-tap flying game with relaxing original ambient music.

**Full description:**
Take a tiny bird on a dreamy sky adventure in Skyflutter. Tap to flap, weave through glowing gates, and try to beat your best score. Enjoy a pastel twilight sky, gentle synthesized ambient music, and simple one-touch controls.

Features:
- Easy one-touch controls
- Dreamy night-sky visuals
- Original synthesized music and sound effects
- Personal best score saved on your device
- Play offline

Skyflutter is an independent arcade game and is not affiliated with or endorsed by the creators of Flappy Bird.

**Important:** Search Play Store for name conflicts before choosing the final title. Do not use “Flappy Bird” as the app name or imply official affiliation. Create original screenshots and a 512x512 store icon before submission.
