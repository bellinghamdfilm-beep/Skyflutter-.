# Skyflutter Privacy Policy — draft to review before publishing

Skyflutter is an offline arcade game prototype. The current source code does not request internet access, does not include analytics or advertising SDKs, and stores the best score locally on the user's device using browser local storage.

No personal information is intentionally collected or transmitted by this version.

If advertising, analytics, crash reporting, online leaderboards, or other SDKs are added later, this policy and the Google Play Data safety form must be updated to accurately describe their data practices. Publish this policy at a publicly accessible URL and verify it matches the final binary before submitting.
